from .FCN import FCNet
from .fourier1d import FNO1d
from .fourier2d import FNO2d
from .fourier3d import FNO3d

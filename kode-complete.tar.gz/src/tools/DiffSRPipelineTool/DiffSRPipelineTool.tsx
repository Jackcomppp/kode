import { Box, Text } from 'ink'
import React from 'react'
import { z } from 'zod'
import { Tool } from '../../Tool.js'
import { exec } from 'child_process'
import { promisify } from 'util'
import path from 'path'
import { getCwd } from '@utils/state'
import { OceanDepsManager } from '@utils/oceanDepsManager.js'

const execAsync = promisify(exec)

const inputSchema = z.strictObject({
	operation: z.enum(['train', 'inference', 'list_models', 'list_configs']).describe(
		'Operation: train (full training), inference (prediction), list_models, list_configs'
	),
	config_path: z.string().optional().describe('Path to YAML config file (for training)'),
	model_type: z.enum([
		'fno', 'edsr', 'swinir', 'ddpm', 'sr3', 'resshift',
		'hinote', 'mwt', 'galerkin', 'm2no', 'mg_ddpm',
		'remg', 'sronet', 'unet', 'wdno'
	]).optional().describe('Model architecture type'),
	dataset_type: z.enum(['ocean', 'era5', 'era5_temperature', 'era5_wind', 'ns2d']).optional().describe('Dataset type'),
	model_path: z.string().optional().describe('Path to trained model checkpoint (for inference)'),
	input_data: z.string().optional().describe('Input data path (for inference)'),
	output_dir: z.string().optional().describe('Output directory for results'),
	gpu_id: z.number().default(0).describe('GPU device ID (-1 for CPU)'),
	epochs: z.number().optional().describe('Number of training epochs'),
	batch_size: z.number().optional().describe('Batch size'),
	learning_rate: z.number().optional().describe('Learning rate'),
})

type Input = z.infer<typeof inputSchema>

type Output = {
	result: string
	durationMs: number
}

const DESCRIPTION = `Complete DiffSR pipeline for super-resolution tasks.

**Embedded DiffSR Framework** - No external installation required!

Includes 15+ model architectures:
- FNO, EDSR, SwinIR, DDPM, ResShift, and more
- Multiple dataset types (Ocean, ERA5, NS2D)
- Training and inference workflows
- Diffusion-based forecastors

Operations:
1. list_models - Show all available model architectures
2. list_configs - List template configuration files
3. train - Train models with YAML config
4. inference - Run super-resolution inference

Training workflow:
- Provide config_path pointing to YAML config in embedded DiffSR
- Optionally override epochs, batch_size, learning_rate
- System executes training using embedded code

Inference workflow:
- Provide model_path (trained checkpoint)
- Provide input_data (low-resolution data)
- System loads model from embedded framework

Example training:
{
  "operation": "train",
  "config_path": "template_configs/Ocean/fno.yaml",
  "output_dir": "outputs/ocean_fno",
  "epochs": 100,
  "batch_size": 8
}

Example inference:
{
  "operation": "inference",
  "model_path": "outputs/ocean_fno/checkpoint.pth",
  "input_data": "data/ocean_lr.npy",
  "output_dir": "results/ocean_sr"
}`

const MODELS = [
	'fno - Fourier Neural Operator',
	'edsr - Enhanced Deep Super-Resolution',
	'swinir - Swin Transformer for Image Restoration',
	'ddpm - Denoising Diffusion Probabilistic Model',
	'sr3 - Image Super-Resolution via Iterative Refinement',
	'resshift - Residual Shift Diffusion Model',
	'hinote - Hierarchical Neural Operator',
	'mwt - Multi-scale Wavelet Transform',
	'galerkin - Galerkin Transformer',
	'm2no - Multi-scale Multi-fidelity Neural Operator',
	'mg_ddpm - Multi-grid DDPM',
	'remg - Residual Multi-grid',
	'sronet - Super-Resolution Operator Network',
	'unet - U-Net Architecture',
	'wdno - Wavelet-based Denoising Neural Operator'
]

export const DiffSRPipelineTool = {
	name: 'DiffSRPipeline',
	async description() {
		return DESCRIPTION
	},
	userFacingName() {
		return 'DiffSR Pipeline'
	},
	inputSchema,
	async isEnabled() {
		return true
	},
	isReadOnly() {
		return false
	},
	isConcurrencySafe() {
		return false
	},
	needsPermissions() {
		return true
	},
	async prompt() {
		return DESCRIPTION
	},
	renderToolUseMessage(input: Input, { verbose }: { verbose: boolean }) {
		return `${input.operation}${input.model_type ? ` (${input.model_type})` : ''}${verbose && input.config_path ? ` config: ${input.config_path}` : ''}`
	},
	renderToolResultMessage(output: Output) {
		return (
			<Box flexDirection="column">
				<Text color="green">Pipeline operation complete ({output.durationMs}ms)</Text>
			</Box>
		)
	},
	renderResultForAssistant(output: Output) {
		return output.result
	},
	async *call(params: Input, { abortController }: { abortController: AbortController }) {
		const start = Date.now()

		try {
			// Use embedded DiffSR from Kode
			yield {
				type: 'text' as const,
				text: '🔧 Using embedded DiffSR framework...\n'
			}
			
			const runtime = await OceanDepsManager.getRuntimeConfig()
			const diffsr_path = runtime.diffsr_path
			const python_path = runtime.python_path
			
			yield {
				type: 'text' as const,
				text: `✓ Embedded DiffSR: ${diffsr_path}\n✓ Python: ${python_path}\n\n`
			}

			const { operation } = params

			if (operation === 'list_models') {
				const output: Output = {
					result: MODELS.join('\n'),
					durationMs: Date.now() - start,
				}
				yield {
					type: 'result' as const,
					resultForAssistant: this.renderResultForAssistant(output),
					data: output,
				}
				return
			}

			if (operation === 'list_configs') {
				const configScript = `
import os
import json
from pathlib import Path

diffsr_path = Path("${diffsr_path.replace(/\\/g, '/')}")
template_dir = diffsr_path / "template_configs"

configs = []
for root, dirs, files in os.walk(template_dir):
    for file in files:
        if file.endswith('.yaml'):
            rel_path = os.path.relpath(os.path.join(root, file), template_dir)
            configs.append(rel_path)

print(json.dumps(configs, indent=2))
`
				const tempScript = path.join(getCwd(), '.diffsr_list_configs.py')
				const fs = await import('fs/promises')
				await fs.writeFile(tempScript, configScript)

				const { stdout } = await execAsync(`"${python_path}" "${tempScript}"`)
				await fs.unlink(tempScript)

				const output: Output = {
					result: stdout,
					durationMs: Date.now() - start,
				}
				yield {
					type: 'result' as const,
					resultForAssistant: this.renderResultForAssistant(output),
					data: output,
				}
				return
			}

			if (operation === 'train') {
				if (!params.config_path) {
					throw new Error('config_path required for training')
				}

				yield {
					type: 'text' as const,
					text: '🚀 Starting DiffSR training directly...\n\n'
				}

				// Verify files exist
				const fs = await import('fs/promises')
				const mainPyPath = path.join(diffsr_path, 'main.py')
				
				try {
					await fs.access(mainPyPath)
					await fs.access(params.config_path)
				} catch (e) {
					throw new Error(`File not found: ${e}`)
				}

				yield {
					type: 'text' as const,
					text: `✓ DiffSR main.py: ${mainPyPath}\n✓ Config: ${params.config_path}\n✓ Python: ${python_path}\n\n`
				}

				// Build command to run training in DiffSR directory
				const isWindows = process.platform === 'win32'
				let trainCommand: string
				
				if (isWindows) {
					// Windows: use cmd /c to change directory and run
					trainCommand = `cmd /c "cd /d "${diffsr_path}" && "${python_path}" main.py --config "${params.config_path}""`
				} else {
					// Linux/Mac: use sh -c
					trainCommand = `cd "${diffsr_path}" && "${python_path}" main.py --config "${params.config_path}"`
				}

				yield {
					type: 'text' as const,
					text: `⏳ Executing training command...\n📝 Command: ${trainCommand}\n\n`
				}

				yield {
					type: 'text' as const,
					text: '=' .repeat(60) + '\n'
				}
				yield {
					type: 'text' as const,
					text: 'TRAINING OUTPUT:\n'
				}
				yield {
					type: 'text' as const,
					text: '=' .repeat(60) + '\n\n'
				}

				try {
					const { stdout, stderr } = await execAsync(trainCommand, {
						maxBuffer: 200 * 1024 * 1024, // 200MB buffer
						timeout: 24 * 60 * 60 * 1000, // 24 hours timeout
						cwd: diffsr_path, // Set working directory
					})

					yield {
						type: 'text' as const,
						text: stdout + '\n'
					}

					if (stderr) {
						yield {
							type: 'text' as const,
							text: `\n⚠️  Warnings/Errors:\n${stderr}\n`
						}
					}

					yield {
						type: 'text' as const,
						text: '\n' + '=' .repeat(60) + '\n'
					}

					const output: Output = {
						result: `Training completed successfully!\n\nOutput saved. Check logs in config output directory.`,
						durationMs: Date.now() - start,
					}
					yield {
						type: 'result' as const,
						resultForAssistant: this.renderResultForAssistant(output),
						data: output,
					}
				} catch (execError: any) {
					// Handle execution errors
					const errorMsg = execError.message || String(execError)
					const stdout = execError.stdout || ''
					const stderr = execError.stderr || ''
					
					yield {
						type: 'text' as const,
						text: `\n❌ Training failed or interrupted\n\n`
					}
					
					if (stdout) {
						yield {
							type: 'text' as const,
							text: `Last output:\n${stdout}\n\n`
						}
					}
					
					if (stderr) {
						yield {
							type: 'text' as const,
							text: `Error details:\n${stderr}\n\n`
						}
					}

					const output: Output = {
						result: `Training error: ${errorMsg}\n\nPartial output captured above.`,
						durationMs: Date.now() - start,
					}
					yield {
						type: 'result' as const,
						resultForAssistant: this.renderResultForAssistant(output),
						data: output,
					}
				}
				return
			}

			if (operation === 'inference') {
				if (!params.model_path || !params.input_data) {
					throw new Error('model_path and input_data required for inference')
				}

				const inferenceScript = `
import sys
import os
from pathlib import Path
import json
import numpy as np
import torch

# Add DiffSR to path
diffsr_path = Path("${diffsr_path.replace(/\\/g, '/')}")
sys.path.insert(0, str(diffsr_path))

try:
    # Load input data
    input_path = "${params.input_data?.replace(/\\/g, '/')}"
    if input_path.endswith('.npy'):
        data = np.load(input_path)
    elif input_path.endswith('.npz'):
        data_dict = np.load(input_path)
        data = data_dict[list(data_dict.keys())[0]]
    else:
        raise ValueError("Unsupported input format")

    # Load model checkpoint
    model_path = "${params.model_path?.replace(/\\/g, '/')}"
    checkpoint = torch.load(model_path, map_location='cpu')

    device = torch.device(f'cuda:${params.gpu_id}' if ${params.gpu_id} >= 0 and torch.cuda.is_available() else 'cpu')

    result = {
        'status': 'inference_ready',
        'model': model_path,
        'input_shape': list(data.shape),
        'device': str(device),
        'checkpoint_keys': list(checkpoint.keys())[:5],
        'message': 'Model and data loaded. Use forecastors module for actual inference.'
    }

    ${params.output_dir ? `
    output_dir = Path("${params.output_dir.replace(/\\/g, '/')}")
    output_dir.mkdir(parents=True, exist_ok=True)
    result['output_dir'] = str(output_dir)
    ` : ''}

    print(json.dumps(result, indent=2))

except Exception as e:
    print(json.dumps({'error': str(e)}), file=sys.stderr)
    sys.exit(1)
`
				const tempScript = path.join(getCwd(), '.diffsr_inference.py')
				const fs = await import('fs/promises')
				await fs.writeFile(tempScript, inferenceScript)

				const { stdout, stderr } = await execAsync(`"${python_path}" "${tempScript}"`, {
					maxBuffer: 50 * 1024 * 1024,
				})

				await fs.unlink(tempScript)

				if (stderr && !stdout) {
					throw new Error(stderr)
				}

				const output: Output = {
					result: stdout || 'Inference configured',
					durationMs: Date.now() - start,
				}
				yield {
					type: 'result' as const,
					resultForAssistant: this.renderResultForAssistant(output),
					data: output,
				}
				return
			}
		} catch (error) {
			const errorMessage = error instanceof Error ? error.message : String(error)
			const output: Output = {
				result: `Error: ${errorMessage}`,
				durationMs: Date.now() - start,
			}
			yield {
				type: 'result' as const,
				resultForAssistant: this.renderResultForAssistant(output),
				data: output,
			}
		}
	},
} satisfies Tool<typeof inputSchema, Output>
